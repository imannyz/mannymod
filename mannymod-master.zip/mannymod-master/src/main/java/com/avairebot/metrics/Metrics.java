/*
 * Copyright (c) 2018.
 *
 * This file is part of MannyMod.
 *
 * MannyMod is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MannyMod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MannyMod.  If not, see <https://www.gnu.org/licenses/>.
 *
 *
 */

package com.avairebot.metrics;

import ch.qos.logback.classic.LoggerContext;
import com.avairebot.MannyMod;
import com.avairebot.blacklist.Ratelimit;
import com.avairebot.commands.Category;
import com.avairebot.commands.utility.GlobalLeaderboardCommand;
import com.avairebot.commands.utility.LeaderboardCommand;
import com.avairebot.commands.utility.RankCommand;
import com.avairebot.contracts.commands.InteractionCommand;
import com.avairebot.contracts.middleware.Middleware;
import com.avairebot.database.controllers.GuildController;
import com.avairebot.database.controllers.PlayerController;
import com.avairebot.database.controllers.PlaylistController;
import com.avairebot.handlers.adapter.JDAStateEventAdapter;
import com.avairebot.level.LevelManager;
import com.avairebot.metrics.filters.AreWeReadyYetFilter;
import com.avairebot.metrics.filters.HttpFilter;
import com.avairebot.metrics.handlers.SparkExceptionHandler;
import com.avairebot.metrics.routes.*;
import com.avairebot.middleware.ThrottleMiddleware;
import com.avairebot.scheduler.jobs.LavalinkGarbageNodeCollectorJob;
import io.prometheus.client.Counter;
import io.prometheus.client.Gauge;
import io.prometheus.client.Histogram;
import io.prometheus.client.guava.cache.CacheMetricsCollector;
import io.prometheus.client.hotspot.DefaultExports;
import io.prometheus.client.logback.InstrumentedAppender;
import net.dv8tion.jda.core.events.Event;
import org.reflections.Reflections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import spark.Spark;

import java.lang.reflect.Modifier;
import java.util.Set;

public class Metrics {

    // ################################################################################
    // ##                              JDA Stats
    // ################################################################################

    public static final Counter jdaEvents = Counter.build()
        .name("mannymod_jda_events_received_total")
        .help("All events that JDA provides us with by class")
        .labelNames("class") // GuildJoinedEvent, MessageReceivedEvent, ReconnectEvent etc
        .register();

    public static final Gauge memoryTotal = Gauge.build()
        .name("mannymod_memory_total")
        .help("Total number bytes of memory dedicated to the app")
        .register();

    public static final Gauge memoryUsed = Gauge.build()
        .name("mannymod_memory_used")
        .help("Total number bytes used in memory for the app")
        .register();

    // ################################################################################
    // ##                             MannyMod Stats
    // ################################################################################

    public static final Gauge uptime = Gauge.build()
        .name("mannymod_uptime")
        .help("Total number of seconds the bot has been online for")
        .labelNames("type")
        .register();

    public static final Gauge guilds = Gauge.build()
        .name("mannymod_guilds_total")
        .help("Total number of guilds the bot is in")
        .register();

    public static final Gauge channels = Gauge.build()
        .name("mannymod_channels_total")
        .help("Total number of channels the bot is in")
        .labelNames("type")
        .register();

    public static final Gauge users = Gauge.build()
        .name("mannymod_users_total")
        .help("Total number of users the bot is in")
        .register();

    public static final Gauge geoTracker = Gauge.build()
        .name("mannymod_geo_tracker_total")
        .help("Total number of guilds split up by geographic location")
        .labelNames("region")
        .register();

    public static final Gauge websocketHeartbeat = Gauge.build()
        .name("mannymod_shard_websocket_heartbeat")
        .help("Websocket heartbeat in milliseconds for each shard")
        .labelNames("shard")
        .register();

    // Music

    public static final Counter searchRequests = Counter.build() //search requests issued by users
        .name("mannymod_music_search_requests_total")
        .help("Total search requests")
        .register();

    public static final Counter tracksLoaded = Counter.build()
        .name("mannymod_music_tracks_loaded_total")
        .help("Total tracks loaded by the audio loader")
        .register();

    public static final Counter trackLoadsFailed = Counter.build()
        .name("mannymod_music_track_loads_failed_total")
        .help("Total failed track loads by the audio loader")
        .register();

    public static final Gauge musicPlaying = Gauge.build()
        .name("mannymod_guild_music_playing_total")
        .help("Total number of guilds listening to music")
        .register();

    // Commands

    public static final Counter commandsRatelimited = Counter.build()
        .name("mannymod_commands_ratelimited_total")
        .help("Total ratelimited commands")
        .labelNames("class") // use the simple name of the command class
        .register();

    public static final Counter commandsReceived = Counter.build()
        .name("mannymod_commands_received_total")
        .help("Total received commands. Some of these might get ratelimited.")
        .labelNames("class")
        .register();

    public static final Counter commandsExecuted = Counter.build()
        .name("mannymod_commands_executed_total")
        .help("Total executed commands by class")
        .labelNames("class")
        .register();

    public static final Histogram executionTime = Histogram.build() // commands execution time, excluding ratelimited ones
        .name("mannymod_command_execution_duration_seconds")
        .help("Command execution time, excluding handling ratelimited commands.")
        .labelNames("class")
        .register();

    public static final Counter commandExceptions = Counter.build()
        .name("mannymod_commands_exceptions_total")
        .help("Total uncaught exceptions thrown by command invocation")
        .labelNames("class") // class of the exception
        .register();

    public static final Counter commandAttempts = Counter.build()
        .name("mannymod_command_attempts_total")
        .help("Total amount of command attempts by class")
        .labelNames("class")
        .register();

    // AI Requests

    public static final Counter aiRequestsReceived = Counter.build()
        .name("mannymod_ai_received_total")
        .help("Total received ai requests.")
        .register();

    public static final Counter aiRequestsExecuted = Counter.build()
        .name("mannymod_ai_executed_total")
        .help("Total executed ai intents by class")
        .labelNames("class")
        .register();

    public static final Histogram aiExecutionTime = Histogram.build()
        .name("mannymod_ai_execution_duration_seconds")
        .help("AI intent execution time.")
        .labelNames("class")
        .register();

    // Database requests

    public static final Counter databaseQueries = Counter.build()
        .name("mannymod_database_queries")
        .help("Total prepared statements created for the given type")
        .labelNames("type")
        .register();

    // Vote statistics

    public static final Counter dblVotes = Counter.build()
        .name("mannymod_dbl_votes")
        .help("Vote requests through the webhook vs the command check")
        .labelNames("type")
        .register();

    public static final Gauge validVotes = Gauge.build()
        .name("mannymod_total_valid_votes")
        .help("The amount of valid votes currently active, updated once every minute")
        .register();

    // Blacklist

    public static final Gauge blacklist = Gauge.build()
        .name("mannymod_blacklist_current")
        .help("The amount of servers and users that are currently on the blacklist")
        .labelNames("type")
        .register();

    // ################################################################################
    // ##                           Method Stuff
    // ################################################################################

    public static final Logger log = LoggerFactory.getLogger(Metrics.class);

    private static int port = 1256;

    private static MannyMod mannymod;
    private static boolean isSetup = false;

    public static void setup(MannyMod mannymod) {
        if (isSetup) {
            throw new IllegalStateException("The metrics has already been setup!");
        }

        Metrics.mannymod = mannymod;
        uptime.labels("static").set(System.currentTimeMillis());

        final LoggerContext factory = (LoggerContext) LoggerFactory.getILoggerFactory();
        final ch.qos.logback.classic.Logger root = factory.getLogger(Logger.ROOT_LOGGER_NAME);
        final InstrumentedAppender prometheusAppender = new InstrumentedAppender();
        prometheusAppender.setContext(root.getLoggerContext());
        prometheusAppender.start();
        root.addAppender(prometheusAppender);

        // JVM (hotspot) metrics
        DefaultExports.initialize();
        Metrics.initializeEventMetrics();

        CacheMetricsCollector cacheMetrics = new CacheMetricsCollector().register();
        cacheMetrics.addCache("levels", LevelManager.cache);
        cacheMetrics.addCache("guilds", GuildController.cache);
        cacheMetrics.addCache("players", PlayerController.cache);
        cacheMetrics.addCache("playlists", PlaylistController.cache);
        cacheMetrics.addCache("categoryPrefixes", Category.cache);
        cacheMetrics.addCache("throttleCommands", ThrottleMiddleware.cache);
        cacheMetrics.addCache("middlewareThrottleMessages", Middleware.messageCache);
        cacheMetrics.addCache("autorole", JDAStateEventAdapter.cache);
        cacheMetrics.addCache("rankScores", RankCommand.cache);
        cacheMetrics.addCache("leaderboard", LeaderboardCommand.cache);
        cacheMetrics.addCache("global-leaderboard", GlobalLeaderboardCommand.cache);
        cacheMetrics.addCache("interaction-lottery", InteractionCommand.cache);
        cacheMetrics.addCache("blacklist-ratelimit", Ratelimit.cache);
        cacheMetrics.addCache("lavalink-destroy-cleanup", LavalinkGarbageNodeCollectorJob.cache);

        if (!mannymod.getConfig().getBoolean("metrics.enabled", true)) {
            log.info("Metrics web API is disabled, skipping igniting Spark API");
            Metrics.isSetup = true;
            return;
        }

        port = mannymod.getConfig().getInt("metrics.port", 1256);

        log.info("Igniting Spark API on port: " + port);

        Spark.port(port);

        Spark.notFound(new GetNotFoundRoute(MetricsHolder.METRICS));
        Spark.exception(Exception.class, new SparkExceptionHandler());

        Spark.before(new HttpFilter());
        Spark.before(new AreWeReadyYetFilter(mannymod));

        Spark.get("/leaderboard/:id", new GetLeaderboardPlayers(MetricsHolder.METRICS));
        Spark.get("/players/cleanup", new GetPlayerCleanup(MetricsHolder.METRICS));
        Spark.post("/guilds/cleanup", new PostGuildCleanup(MetricsHolder.METRICS));
        Spark.get("/guilds/cleanup", new GetGuildCleanup(MetricsHolder.METRICS));
        Spark.get("/guilds/:ids/exists", new GetGuildsExists(MetricsHolder.METRICS));
        Spark.get("/guilds/:ids", new GetGuilds(MetricsHolder.METRICS));
        Spark.get("/metrics", new GetMetrics(MetricsHolder.METRICS));
        Spark.get("/stats", new GetStats(MetricsHolder.METRICS));
        Spark.post("/vote", new PostVote(MetricsHolder.METRICS));

        Metrics.isSetup = true;
    }

    private static void initializeEventMetrics() {
        Set<Class<? extends Event>> types = new Reflections("net.dv8tion.jda.core.events")
            .getSubTypesOf(Event.class);

        for (Class<? extends Event> type : types) {
            if (type.isInterface() || Modifier.isAbstract(type.getModifiers())) {
                continue;
            }
            Metrics.jdaEvents.labels(type.getSimpleName()).inc(0D);
        }
    }

    public MannyMod getMannyMod() {
        return mannymod;
    }

    private static class MetricsHolder {
        private static final Metrics METRICS = new Metrics();
    }
}
