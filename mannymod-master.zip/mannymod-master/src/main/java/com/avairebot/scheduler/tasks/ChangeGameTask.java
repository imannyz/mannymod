/*
 * Copyright (c) 2018.
 *
 * This file is part of MannyMod.
 *
 * MannyMod is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MannyMod is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MannyMod.  If not, see <https://www.gnu.org/licenses/>.
 *
 *
 */

package com.avairebot.scheduler.tasks;

import com.avairebot.MannyMod;
import com.avairebot.contracts.scheduler.Task;
import com.avairebot.utilities.NumberUtil;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.entities.Game;

import java.util.Arrays;

public class ChangeGameTask implements Task {

    public static boolean hasCustomStatus = false;

    private int index = 0;

    @Override
    public void handle(MannyMod mannymod) {
        if (hasCustomStatus || !mannymod.areWeReadyYet()) {
            return;
        }

        if (index >= mannymod.getConfig().getStringList("playing").size()) {
            index = 0;
        }

        String playing = mannymod.getConfig().getStringList("playing").get(index);

        if (playing.trim().length() != 0) {
            for (JDA shard : mannymod.getShardManager().getShards()) {
                shard.getPresence().setGame(getGameFromType(mannymod, playing, shard));
            }
        } else {
            mannymod.getShardManager().setGame(null);
        }

        index++;
    }

    private Game getGameFromType(MannyMod mannymod, String status, JDA shard) {
        if (!status.contains(":")) {
            return Game.playing(formatGame(mannymod, status, shard));
        }

        String[] split = status.split(":");
        status = String.join(":", Arrays.copyOfRange(split, 1, split.length));
        switch (split[0].toLowerCase()) {
            case "listen":
            case "listening":
                return Game.listening(formatGame(mannymod, status, shard));

            case "watch":
            case "watching":
                return Game.watching(formatGame(mannymod, status, shard));

            case "stream":
            case "streaming":
                return Game.streaming(formatGame(mannymod, status, shard), "https://www.twitch.tv/imannyzrbx");

            default:
                return Game.playing(formatGame(mannymod, status, shard));
        }
    }

    private String formatGame(MannyMod mannymod, String game, JDA shard) {
        game = game.replaceAll("%users%", NumberUtil.formatNicely(mannymod.getShardEntityCounter().getUsers()));
        game = game.replaceAll("%guilds%", NumberUtil.formatNicely(mannymod.getShardEntityCounter().getGuilds()));

        game = game.replaceAll("%shard%", shard.getShardInfo().getShardString());
        game = game.replaceAll("%shard-id%", "" + shard.getShardInfo().getShardId());
        game = game.replaceAll("%shard-total%", "" + shard.getShardInfo().getShardTotal());

        return game;
    }
}
